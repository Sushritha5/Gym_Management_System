<?php include 'connection.php' ?>
<?php include 'head.php' ?>
<?php SESSION_start(); ?>
<?php 
$username =$_POST['username'];
$password =$_POST['password'];
if($username=='admin' && $password == 'admin'){
  $_SESSION["role"] = 'admin';
  $url = "adminHome.php";
  header("Location:".$url);
}else{
  $url = "msg.php?msg=Invalid Login Details&class=text-danger";
  header("Location:".$url);
}
?>
