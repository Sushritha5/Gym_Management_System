<?php include 'connection.php'; ?>
<?php include 'gymHead.php' ?>
<?php 
    $FoodDiet_id = $_GET['FoodDiet_id'];
    $sql = "delete  from FoodDiet where FoodDiet_id='".$FoodDiet_id."'"; 
    if($conn->query($sql)==TRUE){
        $url =  "viewManagerCustomer.php";
        header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
    }

?>
