<?php include 'managerHead.php' ?>
<div class="row m-auto">
    <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>
    <div class="col-md-10">
        <div class="card mt-5 p-3">
                <div class="text-center h4">Add Gym Trainer</div>
                <form action="addGymTrainer1.php" method="post">
                     <div class="row m-auto">
                        <div class="col-md-6">
                            <label for="trainer_name" class="form-label">Trainer Name</label>
                            <input type="text" name="name" id="trainer_name" placeholder="Enter Name" required class="form-control">
                        </div>
                        <div class="col-md-6 ">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" id="email" placeholder="Enter Email" required class="form-control">
                        </div>
                       <div class="col-md-6 mt-1">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="number" name="phone" id="phone" placeholder="Enter Phone Number" required class="form-control">
                        </div>
                         <div class="col-md-6 mt-1">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="password" id="password" placeholder="Enter Password" required class="form-control">
                          </div>
                        <div class="col-md-6 mt-1">
                            <label for="experience">Experience</label>
                            <input type="number" name="experience" id="experience" placeholder="Enter Experience" required class="form-control mt-1">
                        </div>
                       <div class="col-md-6 mt-1">
                            <label for="about_trainer">About Trainer</label>
                            <textarea name="about" id="about_trainer" placeholder="About" required class="form-control"></textarea>
                        </div>
                         <div class="mt-5">
                            <input type="submit" value="Add Trainer" class="btn btn-success w-100">
                         </div>
                     </div>
                </form>
            </div>
      </div>
</div>





