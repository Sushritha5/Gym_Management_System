<?php SESSION_start(); ?>
<?php if(!isset($_SESSION['role'])){
    include 'head.php';
  }elseif($_SESSION["role"]=='admin'){
     include 'adminHead.php';
  }
  elseif($_SESSION["role"]=='BranchManager'){
    include 'managerHead.php';
 }elseif($_SESSION["role"]=='GymTrainer'){
    include 'gymHead.php';
 }
 elseif($_SESSION["role"]=='Customer'){
   include 'customerHead.php';

 }

 ?>
<?php 
    $msg = $_GET['msg'];
    $class = $_GET['class'];
?>
<div  class="row">
    <div class="col-md-2">
    </div>
    <div class="col-md-8">  
        <div class="text-center h5 mt-5 <?php echo $class ?>"><?php echo $msg ?></div>
    </div>
    <div class="col-md-2">
    </div>
</div>