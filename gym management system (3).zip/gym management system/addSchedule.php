<?php include 'managerHead.php' ?>
<?php include 'connection.php' ?>
<?php SESSION_start(); ?>

<?php 
  $Customer_id = $_GET['Customer_id'];
  $sql = "select * from MemberShip  ";
  $MemberShips = $conn->query($sql);
  $sql = "select * from GymTrainer where Branch_id='".$_SESSION['Branch_id']."'  ";
  $GymTrainers = $conn->query($sql);
?>
<div class="row m-auto">
  <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>
  <div class="col-md-10">
       <div class="row m-auto">
            <div class="col-md-4"></div>
            <div class="col-md-4 mt-5">
                <div class="card mt-5 p-3">
                  <div class="text-center h4">Add Schedule</div>
                  <form action="addSchedule1.php" method="post">
                    <input type="hidden" name="Customer_id" value="<?php echo $Customer_id?>">
                      <div class="mt-3">
                        <select name="MemberShip_id" required class="form-control">
                            <option value="">Choose Membership</option>
                           <?php foreach($MemberShips as $MemberShip){?>
                              <option value="<?php echo $MemberShip['MemberShip_id']?>"><?php echo $MemberShip['membership_name']?></option>
                            <?php }?>
                        </select>
                        </div>
                        <div class="mt-3">
                            <select name="GymTrainer_id" class="form-control">
                                <option value="">Choose Trainer</option>
                                <option value="">Trainer Not Required</option>
                                <?php foreach($GymTrainers as $GymTrainer){?>
                                    <option value="<?php echo $GymTrainer['GymTrainer_id']?>"><?php echo $GymTrainer['name']?></option>
                                    <?php }?>
                            </select>
                         </div>
                         <div class="mt-3">
                            <label for="start_time" class="form-label">From Time</label>
                           <input type="time" name="start_time" id="start_time"  required class="form-control">
                        </div>
                        <div class="mt-3">
                          <label for="end_time" class="form-label">To Time</label>
                           <input type="time" name="end_time" id="end_time"  required class="form-control">
                        </div>
                       <div class="mt-3">
                           <input type="submit"  value="Add" class="btn btn-success w-100">
                        </div>
                  </form>
                </div>
            </div>
         </div>
    </div>
</div>
