<?php include 'managerHead.php' ?>
<div class="row m-auto">
  <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh"></div>
  <div class="col-md-10">
  <div class="text-center" style="font-size:60px;margin-top:100px;">
    Branch Manager Home Page
  </div>
</div>
</div>
