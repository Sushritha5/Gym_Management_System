<?php include 'gymHead.php' ?>
<?php include 'connection.php' ?>
<?php 
  $Schedule_id = $_GET['Schedule_id'];
?>
<div class="row m-auto">
  <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>
  <div class="col-md-10">
       <div class="row m-auto">
            <div class="col-md-4"></div>
            <div class="col-md-4 mt-5">
                <div class="card mt-5 p-3">
                  <div class="text-center h4">Add Food Diet</div>
                  <form action="addFoodDiet1.php" method="post">
                  <input type="hidden" name="Schedule_id" value="<?php echo $Schedule_id?>">
                      <div class="mt-3">
                            <label for="food_name" class="form-label">Food Name</label>
                            <input type="text" name="food_name" id="food_name" placeholder="Enter Name" required class="form-control">
                        </div>
                        <div class="mt-3">
                          <label for="description" class="form-label">Description</label>
                            <textarea name="description" id="description"  required class="form-control"></textarea>
                        </div>
                       <div class="mt-3">
                           <input type="submit"  value="Add Food Diet" class="btn btn-success w-100">
                        </div>
                  </form>
                </div>
            </div>
       </div>
  </div>
</div>