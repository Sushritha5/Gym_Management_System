<?php SESSION_start(); ?>
<?php if($_SESSION['role']=='BranchManager'){
    include 'managerHead.php';
  }elseif($_SESSION["role"]=='GymTrainer'){
       include 'gymHead.php';

  }
 ?>
<?php include 'connection.php' ?>
<?php 

if($_SESSION['role']=='BranchManager'){
    if(isset($_GET['name'])&&isset($_GET['phone'])){
        $sql = "select * from Customer where Branch_id ='".$_SESSION['Branch_id']."'  and name like '%".$_GET['name']."%' and phone like '%".$_GET['phone']."%'";
        $results = $conn->query($sql);
    }else{
        $sql = "select * from Customer where Branch_id ='".$_SESSION['Branch_id']."' ";
        $results = $conn->query($sql);
    }
    
}elseif($_SESSION['role']=='GymTrainer'){
    if(isset($_GET['name'])&&isset($_GET['phone'])){
        $sql = "select * from Customer where Customer_id in (select Customer_id from Schedule where GymTrainer_id ='".$_SESSION['GymTrainer_id']."') and name like '%".$_GET['name']."%' and phone like '%".$_GET['phone']."%'";
        $results = $conn->query($sql);
    }else{
        $sql = "select * from Customer where Customer_id in (select Customer_id from Schedule where GymTrainer_id ='".$_SESSION['GymTrainer_id']."')";
        $results = $conn->query($sql);
    }
   
}
?>
<div style="height:100vh; overflow:auto">
    <div class="row m-auto">
       <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh"></div>
        <div class="col-md-10">
           <div class="card ms-5 me-5 mt-3 p-3">
                <form action="viewManagerCustomer.php">
                    <div class="row">
                         <div class="col-md-4">
                            <label for="customer_name" class="form-label h5">Customer Name</label>
                            <input type="text" name="name" placeholder="Name" id="customer_name" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label for="phone" class="form-label h5">Customer Phone Number</label>
                            <input type="number" name="phone" placeholder="Phone" id="phone" class="form-control">
                        </div>
                          <div class="col-md-4 mt-4 p-2">
                            <input type="submit" value="Search" class="btn btn-success w-100" style="margin-bottom:0px">
                        </div>
                   </div>
                </form>
            </div>
            <?php foreach($results as $data){
            $sql2 = "select * from Branches where Branch_id='".$data['Branch_id']."'";
            $Branches = $conn->query($sql2);
            $sql3 = "select * from MemberShip where MemberShip_id='".$data['MemberShip_id']."'";
            $MemberShips = $conn->query($sql3);
            ?>
              <div class="card ms-5 me-5 mt-3 p-3">
               
                  <div class="row">
                      <div class="col-md-4">
                          <div class="card p-3">
                         
                              <div class="text-center h5 mt-2 color= text-primary">Customer Details</div>
                              <div class="mt-1">
                                
                                  <div class="text-muted" style="font-size:80%">Customer Name</div>
                                  <div class="h6"><?php echo $data['name']?></div>
                              </div>
                              <div class="mt-1">
                                  <div class="text-muted" style="font-size:80%">Phone Number</div>
                                  <div class="h6"><?php echo $data['phone']?></div>
                              </div>
                              <div class="mt-1">
                                  <div class="text-muted" style="font-size:80%">Email</div>
                                  <div class="h6"><?php echo $data['email']?></div>
                              </div>
                              <div class="mt-1">
                                  <div class="text-muted" style="font-size:80%">BMI</div>
                                  <div class="h6"><?php echo $data['bmi']?></div>
                              </div>
                              <div class="mt-1">
                                  <div class="text-muted" style="font-size:80%">BMR</div>
                                  <div class="h6"><?php echo $data['bmr']?></div>
                              </div>
                              <div class="mt-1">
                                  <div class="text-muted" style="font-size:80%">Height</div>
                                  <div class="h6"><?php echo $data['height']?></div>
                              </div>
                              <div class="mt-1">
                                  <div class="text-muted" style="font-size:80%">Weight</div>
                                  <div class="h6"><?php echo $data['weight']?></div>
                              </div>
                              <div class="mt-1">
                                  <div class="text-muted" style="font-size:80%">Address</div>
                                  <div class="h6"><?php echo $data['address']?></div>
                              </div>
                          </div>
                      </div>
                      <div class="col-md-4">
                          <div class="card p-3">
                              <div class="text-center h5 mt-2 color= text-primary">Schedule Details</div>
                          <?php foreach($MemberShips as $MemberShip){?>
                                <div class="mt-1">
                                    <div class="text-muted" style="font-size:80%">Membership Name</div>
                                     <div class="h6"><?php echo $MemberShip['membership_name']?></div>
                                 </div>
                                <div class="mt-1">
                                    <div class="text-muted" style="font-size:80%">Validity</div>
                                     <div class="h6"><?php echo $MemberShip['validity']?></div>
                                 </div>
                                <div class="mt-1">
                                    <div class="text-muted" style="font-size:80%">Price</div>
                                     <div class="h6"><?php echo $MemberShip['price']?></div>
                                 </div>
                                    <?php
                                        $sql55 = "select * from Schedule where Customer_id='".$data['Customer_id']."'";
                                        $Schedules = $conn->query($sql55);
                                        if ($Schedules ->num_rows > 0) { 
                                        foreach($Schedules as $Schedule){
                                            ?>
                                            <div class="mt-1">
                                                <div class="text-muted" style="font-size:80%">From Time</div>
                                                <div class="h6"><?php echo $Schedule['start_time']?></div>
                                                </div>
                                                <div class="mt-1">
                                                <div class="text-muted" style="font-size:80%">To Time</div>
                                                <div class="h6"><?php echo $Schedule['end_time']?></div>
                                                </div>
                                                <div class="mt-1">
                                                <div class="text-muted" style="font-size:80%">Date</div>
                                                <div class="h6"><?php echo $Schedule['date']?></div>
                                            </div>
                                            <?php
                                            $sql66 = "select * from GymTrainer where GymTrainer_id='".$Schedule['GymTrainer_id']."'";
                                            $Trainers = $conn->query($sql66);
                                            if ($Trainers ->num_rows > 0) { 
                                            foreach($Trainers as $Trainer){ ?>
                                               <div class="mt-1">
                                                    <div class="text-muted" style="font-size:80%">Trainer Name</div>
                                                    <div class="h6"><?php echo $Trainer['name']?></div>
                                                    <div class="text-muted" style="font-size:80%">Trainer Phone</div>
                                                    <div class="h6"><?php echo $Trainer['phone']?></div>
                                                </div>
                                               
                                            <?php }
                                            }else{?>
                                                 <hr>
                                                <div class="text-center h4">Trainer Not Assinged</div>
                                                <hr>
                    
                                            <?php }
                                            
                                        }
                                        
                                        }else{?>
                                            <div class="mt-3">
                                             <a href="addSchedule.php?Customer_id=<?php echo $data['Customer_id']?>" class="btn btn-primary w-100">Add Schedule</a>
                                           </div>

                                        <?php }
                                    ?>
                                     
                                <div>
                           
                                </div>
                            
                    
                      </div>
                  </div>
                      <div class="col-md-4">
                      <?php
                            $sql55 = "select * from Schedule where Customer_id='".$data['Customer_id']."'";
                            $Schedules = $conn->query($sql55);
                            if ($Schedules ->num_rows > 0) { 
                                foreach($Schedules as $Schedule){?>
                                <?php if($_SESSION['role']=='GymTrainer'){?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mt-3">
                                            <a href="addExercise.php?Schedule_id=<?php echo $Schedule['Schedule_id']?>" class="btn btn-primary w-100">Add Exersice</a>
                                        </div>
                                    </div>
                                     <div class="col-md-6">
                                        <div class="mt-3">
                                            <a href="addFoodDiet.php?Schedule_id=<?php echo $Schedule['Schedule_id']?>" class="btn btn-primary w-100">Add Food Diet</a>
                                        </div>
                                    </div>
                                </div>
                          <?php }?>
                          <div class="text-success" style="font-size:90%">Exercises</div>
                          <div class="mt-1" style="height:200px;overflow:auto" >
                          <?php
                            $sql55 = "select * from ExcerciseDiet where Schedule_id='".$Schedule['Schedule_id']."'";
                            $ExcerciseDiets = $conn->query($sql55);
                            ?>
                              <?php foreach($ExcerciseDiets as $ExcerciseDiet){?>
                              <div class="card p-3">
                               <div class="row mt-1">
                                   <div class="col-md-8">
                                       <div class="text-muted" style="font-size:80%">Exercise Name</div>
                                        <div class="h6"><?php echo $ExcerciseDiet['exercise_name']?></div>
                                   </div>
                                   <div class="col-md-4">
                                       <a href="deleteExercise.php?ExcerciseDiet_id=<?php echo $ExcerciseDiet['ExcerciseDiet_id']?>" class="btn btn-danger" style="font-size:70%">Delete</a>
                                   </div>

                               </div>
                               <div class="mt-1">
                                   <div class="text-muted" style="font-size:80%">Description</div>
                                   <div class="h6"><?php echo $ExcerciseDiet['description']?></div>
                               </div>
                              </div>
                             <?php } ?>
                               </div>
                          <hr>
                          <div class="text-success" style="font-size:90%">Food Diet</div>
                          <div class="mt-1" style="height:200px;overflow:auto">
                          <?php
                            $sql55 = "select * from FoodDiet where Schedule_id='".$Schedule['Schedule_id']."'";
                            $FoodDiets = $conn->query($sql55);
                            ?>
                              <?php foreach($FoodDiets as $FoodDiet){?>
                                <div class="card p-3">
                                    <div class="mt-1 row">
                                        <div class="col-md-8">
                                            <div class="text-muted" style="font-size:80%">FoodDiet Name</div>
                                            <div class="h6"><?php echo $FoodDiet['food_name']?></div>
                                       </div>
                                       <div class="col-md-4">
                                           <a href="deleteFoodDiet.php?FoodDiet_id=<?php echo $FoodDiet['FoodDiet_id']?>" class="btn btn-danger" style="font-size:70%">Delete</a>
                                       </div>
                                    </div>
                                    <div class="mt-1">
                                         <div class="text-muted" style="font-size:80%">Description</div>
                                         <div class="h6"><?php echo $FoodDiet['description']?></div>
                                    </div>
                                </div>
                              <?php } ?>
                                <?php }}
                                 ?>
                           </div>
                      </div>
                      </div>
                  </div>
                  <?php } ?>
                  <?php } ?>
        </div>
    </div>
</div>



