<?php SESSION_start(); ?>

<?php include 'connection.php'; ?>
<?php include 'managerHead.php' ?>
<?php 
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $experience = $_POST['experience'];
    $about = $_POST['about'];
    $sql = "insert into GymTrainer(name,email,phone,password,experience,about,Branch_id)values('".$name."', '".$email."', '".$phone."', '".$password."', '".$experience."', '".$about."','".$_SESSION['Branch_id']."')";
    if($conn->query($sql)==TRUE){
        $url =  "msg.php?msg=Gym Trainer Added Successfully&class=text-success";;
        header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
    }
?>
