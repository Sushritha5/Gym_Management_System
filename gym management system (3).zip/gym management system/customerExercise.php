<?php SESSION_start(); ?>
<?php include 'customerHead.php' ?>
<?php include 'connection.php' ?>
<?php 
  $sql = "select * from Schedule where Customer_id ='".$_SESSION['Customer_id']."' ";
  $results = $conn->query($sql);
?>
<div class="row m-auto">
    <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>
  <div class="col-md-10 mt-3">
    
      <div class="text-center h4 text-primary">Suggested Exercises</div>
       <div class="row mt-3">
       <?php foreach($results as $data){
         $sql = "select * from ExcerciseDiet where Schedule_id ='".$data['Schedule_id']."' ";
         $ExcerciseDiets = $conn->query($sql);
        ?>
               <div class="col-md-4">
                   <div class="card p-3">
                   <?php  if ($ExcerciseDiets ->num_rows > 0) { 
                        foreach($ExcerciseDiets as $ExcerciseDiet){?>
                       <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">Exercise Name</div>
                            <div class="h6"><?php echo $ExcerciseDiet['exercise_name']?></div>
                       </div>
                       <div class="mt-1">
                           <div class="text-muted" style="font-size:80%">Description</div>
                           <div class="h6" style="height:100px;overflow:auto"><?php echo $ExcerciseDiet['description']?></div>
                       </div>
                   </div>
               </div>
               <?php }
                    }else{?>
                     <div class="text-center h5 mt-5">Results Not Found</div>
               <?php } ?>
       </div>
     <?php } ?>
  </div>
</div>
