<?php SESSION_start(); ?>
<?php include 'customerHead.php' ?>
<?php include 'connection.php' ?>
<?php 
  $sql = "select * from Schedule where Customer_id ='".$_SESSION['Customer_id']."' ";
  $results = $conn->query($sql);
?><div class="row m-auto">
 <div class="col-md-2" style="background-image:url('http://www.fitstep.com/2/3-beginner-fitness/health-and-fitness-articles/graphics/energy-rich1.jpg');height:100vh"></div>
  <div class="col-md-10 mt-3">
 
      <div class="text-center h4 text-primary">Suggested Food Diet</div>
       <div class="row mt-3">
       <?php foreach($results as $data){
         $sql = "select * from FoodDiet where Schedule_id ='".$data['Schedule_id']."' ";
         $FoodDiets = $conn->query($sql);
        ?>
               <div class="col-md-4">
                   <div class="card p-3">
                       <div class="mt-1">
                       <?php  if ($FoodDiets ->num_rows > 0) { 
                        foreach($FoodDiets as $FoodDiet){?>
                            <div class="text-muted" style="font-size:80%">FoodDiet Name</div>
                            <div class="h6"><?php echo $FoodDiet['food_name']?></div>
                       </div>
                       <div class="mt-1">
                           <div class="text-muted" style="font-size:80%">Description</div>
                           <div class="h6" style="height:100px;overflow:auto"><?php echo $FoodDiet['description']?></div>
                       </div>
                   </div>
               </div>
               <?php }
                    }else{?>
                     <div class="text-center h5 mt-5">Results Not Found</div>
               <?php } ?>
       </div>
       <?php } ?>
  </div>
</div>
