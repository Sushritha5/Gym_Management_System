<?php include 'connection.php'; ?>
<?php include 'gymHead.php' ?>
<?php 
    $Schedule_id = $_POST['Schedule_id'];
    $food_name = $_POST['food_name'];
    $description = $_POST['description'];

    $sql = "insert into FoodDiet(food_name,description,Schedule_id)values('".$food_name."', '".$description."', '".$Schedule_id."')"; 
    if($conn->query($sql)==TRUE){
        $url =  "msg.php?msg=FoodDiet Added Successfully&class=text-success";;
        header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
    }

   
    
?>
