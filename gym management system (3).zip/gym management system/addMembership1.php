<?php include 'connection.php'; ?>
<?php include 'adminHead.php'; ?>
<?php 
    $membership_name = $_POST['membership_name'];
    $validity = $_POST['validity'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    $sql = "insert into MemberShip(membership_name,validity,price,description) values('".$membership_name."', '".$validity."', '".$price."', '".$description."')"; 
    if($conn->query($sql)==TRUE){
        $url =  "msg.php?msg=Membership  Added Successfully&class=text-success";;
        header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
    }
?>
?>