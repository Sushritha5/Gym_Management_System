<?php SESSION_start(); ?>
<?php include 'customerHead.php' ?>
<?php include 'connection.php' ?>
<?php 
  $sql = "select * from Schedule where Customer_id ='".$_SESSION['Customer_id']."' ";
  $results = $conn->query($sql);
?>
<div class="row m-auto">
    <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>
    <div class="col-md-10">
      <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-4">
              <div class="card mt-5 p-3">
              <?php foreach($results as $data){
            // $sql2 = "select * from Branches where Branch_id='".$data['Branch_id']."'";
            // $Branches = $conn->query($sql2);
            ?>
                   <div class="text-center h4 text-primary">Schedule Details</div>
                <div class="mt-1">
                    <div class="text-muted" style="font-size:80%">From Time</div>
                    <div class="h6"><?php echo $data['start_time']?></div>
                </div>
               <div class="mt-1">
                   <div class="text-muted" style="font-size:80%">To Time</div>
                   <div class="h6"><?php echo $data['end_time']?></div>
               </div>
               <?php 
                  $sql = "select * from GymTrainer where GymTrainer_id ='".$data['GymTrainer_id']."' ";
                  $results = $conn->query($sql);
                ?>
              <?php  if ($results ->num_rows > 0) { 
                 foreach($results as $trianer){?>
                  <div class="mt-1">
                    <div class="text-muted" style="font-size:80%">Trainer Name</div>
                    <div class="h6"><?php echo $trianer['name']?></div>
                  </div>
                  <div class="mt-1">
                    <div class="text-muted" style="font-size:80%">Trainer Number</div>
                    <div class="h6"><?php echo $trianer['phone']?></div>
                  </div>
                  <?php }
                    }else{?>
                <hr>
                <div class="text-center h4">Trainer Not Assinged</div>
                <hr>
        <?php }?>
            <?php } ?>
         </div>
      </div>
  </div>
  </div>
</div>
