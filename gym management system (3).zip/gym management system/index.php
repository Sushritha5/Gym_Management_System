<?php include 'head.php' ?>

<div class="row m-auto">
<div class="col-md-12" style="background-image:url('https://i.pinimg.com/originals/2d/80/47/2d80474f6f751735de27eab42c9b2ece.jpg');height:100vh;background-repeat:no-repeat;background-size:cover"></div>

    <div class="col-md-2"></div>
    <div class="col-md-10"></div>
</div>
