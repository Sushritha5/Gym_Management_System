<?php include 'adminHead.php' ?>
<div class="row m-auto">
    <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>
    <div class="col-md-10">
        <div class="card mt-5 p-3">
                <div class="text-center h4">Add Branch Manager</div>
                <form action="addManager1.php" method="post">
                     <div class="row m-auto">
                        <div class="col-md-6 mt-3">
                            <label for="branch_name" class="form-label">Branch Name</label>
                            <input type="text" name="branch_name" id="branch_name" placeholder="Enter Branch Name" required class="form-control">
                        </div>
                          <div class="col-md-6 mt-3">
                            <label for="manager_name" class="form-label">Manager Name</label>
                            <input type="text" name="manager_name" id="manager_name" placeholder="Enter Manager Name" required class="form-control">
                          </div>
                          <div class="col-md-6 mt-2">
                            <label for="address">Branch Address</label>
                            <textarea name="branch_address" id="address" placeholder="Enter Address" required class="form-control"></textarea>
                          </div>
                         <div class="col-md-6 mt-2">
                            <label for="about_manager">About Manager</label>
                            <textarea name="about_manager" placeholder="About " id="about_manager" required class="form-control"></textarea>
                        </div>
                        <div class="col-md-6 mt-2">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" id="email" placeholder="Enter Email" required class="form-control">
                        </div>
                       <div class="col-md-6 mt-1">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="number" name="phone" id="phone" placeholder="Enter Phone Number" required class="form-control">
                        </div>
                         <div class="col-md-6 mt-1">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="password" id="password" placeholder="Enter Password" required class="form-control">
                          </div>
                         <div class="col-md-6 mt-4">
                            <input type="submit" value="Add Manager" class="btn btn-success w-100">
                         </div>
                     </div>
                </form>
            </div>
      </div>
</div>




