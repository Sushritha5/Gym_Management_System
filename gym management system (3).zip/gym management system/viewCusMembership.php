<?php include 'customerHead.php' ?>
<?php include 'connection.php' ?>
<?php SESSION_start(); ?>
<?php 

$sql = "select * from MemberShip ";
$MemberShips = $conn->query($sql);

 
 ?>
<div class="row m-auto">
<!--    <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>-->
    <div class="col-md-2"></div>
    <div class="col-md-10">
        <div class="text-center h4 mt-4 color= text-primary">View Membership</div>
        <div class="row m-auto">
         <?php  foreach($MemberShips as $MemberShip){?>

                <div class="col-md-4">
                    <div class="card mt-5 p-3">
                        <div class="mt1">
                            <div class="text-muted" style="font-size:80%">Membership Name</div>
                             <div class="h6"><?php echo $MemberShip['membership_name']?></div>
                        </div>
                        <div class="mt1">
                            <div class="text-muted" style="font-size:80%">Validity</div>
                             <div class="h6"><?php echo $MemberShip['validity']?></div>
                        </div>
                        <div class="mt1">
                            <div class="text-muted" style="font-size:80%">Price</div>
                             <div class="h6"><?php echo $MemberShip['price']?></div>
                        </div>
                         <div class="mt1">
                            <div class="text-muted" style="font-size:80%">Description</div>
                             <div class="h6"><?php echo $MemberShip['description']?></div>
                        </div>
                        <div class="col-md-6">
                            <a href="buyMembership.php?MemberShip_id=<?php echo $MemberShip['MemberShip_id']?>&price=<?php echo $MemberShip['price']?>"  class="btn btn-success w-100">Buy</a>
                        </div>
                    </div>
                </div>
           <?php } ?>
        </div>
    </div>
</div>
