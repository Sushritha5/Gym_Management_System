<head>
<link rel="stylesheet" href="static/css/mystyle.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function () {
        $('.menu').click(function() {
            $('.overlay').toggleClass('anim');
            $(this).addClass('open')
        });

        $('.open').click(function(){
            $('.overlay').toggleClass('reverse-animation');
        })
    });

  </script>
</head>
<div class="wrapper">
    <span class="menu"></span>

    <div class="title">

    </div>

    <div class="overlay">
        <ul>
            <li><a href="gymHome.php">Home</a></li>
            <li><a href="viewManagerCustomer.php">View Customers</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</div>

