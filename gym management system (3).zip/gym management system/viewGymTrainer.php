<?php SESSION_start(); ?>
<?php include 'managerHead.php' ?>
<?php include 'connection.php' ?>
<?php 
  $sql = "select * from GymTrainer where Branch_id ='".$_SESSION['Branch_id']."' ";
  $results = $conn->query($sql);
?>
<div class="row m-auto">
    <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>
    <div class="col-md-10">
        <div class="text-center h4 mt-4 color= text-primary">View Trainers</div>
        <div class="row m-auto">
        <?php foreach($results as $data){
            $sql2 = "select * from Branches where Branch_id='".$data['Branch_id']."'";
            $Branches = $conn->query($sql2);
            ?>
                <div class="col-md-4">
                    <div class="card mt-5 p-3">
                         <div class="mt1">
                         <?php foreach($Branches as $Branch){?>
                            <div class="text-muted" style="font-size:80%">Trainer Name</div>
                            <div class="h6"><?php echo $data['name']?></div>
                         </div>
                        <div class="mt1">
                            <div class="text-muted" style="font-size:80%">Branch Name</div>
                            <div class="h6"><?php echo $Branch['branch_name']?></div>
                         </div>
                        <div class="mt-1">
                            <div class="text-muted" style="font-style:80%">Phone Number</div>
                            <div class="h6"><?php echo $data['phone']?></div>
                         </div>
                        <div class="mt-1">
                            <div class="text-muted" style="font-style:80%">Email</div>
                             <div class="h6"><?php echo $data['email']?></div>
                         </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-style:80%">Experience</div>
                            <div class="h6"><?php echo $data['experience']?></div>
                         </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-style:80%">About Trainer</div>
                            <div class="h6"><?php echo $data['about']?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="text-muted" style="font-style:80%">Status</div>
                                <div class="h6"><?php echo $data['status']?></div>
                            </div>
                             <div class="col-md-6 mt-3">
                                <?php if($data['status']=='Deactivated'){ ?> 
                                     <a href="activateTrainer.php?GymTrainer_id=<?php echo $data['GymTrainer_id']?>"  class="btn btn-success">Activate</a>
                                <?php }?>
                             </div>
                        </div>
                     </div>
                </div>
                <?php }?>
                <?php }?>
        </div>
    </div>
</div>

