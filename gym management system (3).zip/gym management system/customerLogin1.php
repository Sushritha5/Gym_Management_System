<?php include 'connection.php' ?>
<?php include 'head.php' ?>
<?php SESSION_start(); ?>
<?php 
$email =$_POST['email'];
$password =$_POST['password'];
$sql = "select * from Customer where email='".$email."' and password='".$password."'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { 
    while($row = $result->fetch_assoc()) { 
        $_SESSION["role"] = 'Customer';
        $_SESSION["Customer_id"] = $row["Customer_id"];
        $url = "customerHome.php";
        header("Location:".$url);
    }
}else{
    $url = "msg.php?msg=Invalid Login Details&class=text-danger";
    header("Location:".$url);
}
?>
