<?php include 'connection.php' ?>
<?php include 'head.php' ?>
<?php SESSION_start(); ?>
<?php 
$email =$_POST['email'];
$password =$_POST['password'];
$sql = "select * from GymTrainer where email='".$email."' and password='".$password."'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { 
    while($row = $result->fetch_assoc()) { 
        if($row["status"]==='Deactivated'){
            $url = "msg.php?msg=Your  Account not yet verified&class=text-danger&role";
            header("Location:".$url);
        }else{
            $_SESSION["role"] = 'GymTrainer';
            $_SESSION["GymTrainer_id"] = $row["GymTrainer_id"];
            $url = "gymHome.php";
            header("Location:".$url);
        }
       
    }
}else{
    $url = "msg.php?msg=Invalid Login Details&class=text-danger";
    header("Location:".$url);
}
?>
