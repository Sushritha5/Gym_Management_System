<?php include 'customerHead.php' ?>
<?php include 'connection.php' ?>
<?php SESSION_start(); ?>
<?php 
$MemberShip_id = $_GET['MemberShip_id'];
$price = $_GET['price'];

 
 ?>
<div class="row m-auto">
    <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh"></div>
    <div class="col-md-10">
        <div class="row m-auto">
            <div class="col-md-4"></div>
              <div class="col-md-4 mt-5">
                <div class="card mt-5 p-3">
                    <form action="buyMembership1.php" method="post">
                        <input type="hidden" name="MemberShip_id" value="<?php echo $MemberShip_id ?>">
                        <input type="hidden" name="price" value="<?php echo $price ?>">
                          <div class="text-center h4">Payable Amount : $ <?php echo $price ?></div>

                          <div class="mt-3">
                            <label for="card_number" class="form-label">Card Number</label>
                            <input type="number" name="card_number" id="card_number" placeholder="Enter Number" required class="form-control">
                          </div>
                          <div class="mt-3">
                            <label for="card_name" class="form-label">Card Holder Name</label>
                            <input type="text" name="card_name" id="card_name" placeholder="Enter Name" required class="form-control">
                          </div>
                         <div class="mt-3">
                            <label for="cvv" class="form-label">CVV</label>
                            <input type="number" name="cvv" id="cvv" placeholder="Enter CVV" required class="form-control">
                          </div>
                            <div class="mt-3">
                                <label for="expire_date" class="form-label">Expire Date</label>
                                <input type="text"  name="expire_date" id="expire_date" required class="form-control"></inputty>
                            </div>
                         <div class="mt-3">
                            <input type="submit" value="Submit" class="btn btn-success w-100">
                        </div>
                    </form>
                  </div>
                </div>
              <div class="col-md-4"></div>
        </div>
    </div>
</div>


