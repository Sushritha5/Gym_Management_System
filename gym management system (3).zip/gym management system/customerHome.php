<?php include 'customerHead.php' ?>
<?php include 'connection.php' ?>
<?php SESSION_start(); ?>
<?php 
$sql = "select * from Customer where Customer_id='".$_SESSION['Customer_id']."' ";
$results = $conn->query($sql);
 foreach($results as $data){
    $sql = "select * from Branches where Branch_id='".$data['Branch_id']."' ";
    $Branches = $conn->query($sql);
 }
 foreach($results as $data){
    $sql = "select * from MemberShip where MemberShip_id='".$data['MemberShip_id']."' ";
    $MemberShips = $conn->query($sql);
 }
?>
<div class="row m-auto">
  <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh"></div>
  <div class="col-md-10">
      <div class="row m-auto">
          <div class="col-md-4">
              <div class="card mt-5 p-3">
                  <div class="text-center h5" style="color:Violet">Customer Details</div>
                <?php  foreach($results as $data){?>
                  <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">Customer Name</div>
                             <div class="h6"><?php echo $data['name']?></div>
                        </div>
                        <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">Phone Number</div>
                             <div class="h6"><?php echo $data['phone']?></div>
                        </div>
                        <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">Email</div>
                             <div class="h6"><?php echo $data['email']?></div>
                        </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">BMI</div>
                             <div class="h6"><?php echo $data['bmi']?></div>
                        </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">BMR</div>
                             <div class="h6"><?php echo $data['bmr']?></div>
                        </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">Height</div>
                             <div class="h6"><?php echo $data['height']?></div>
                        </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">Weight</div>
                             <div class="h6"><?php echo $data['weight']?></div>
                        </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">Address</div>
                             <div class="h6"><?php echo $data['address']?></div>
                        </div>
                    </div>
                </div>
               <div class="col-md-4">
               <div class="card mt-5 p-3">
               <?php  foreach($Branches as $Branch){?>
                   <div class="text-center h5" style="color:Violet">Manager Details</div>
                   <div class="mt-1">
                            <div class="text-muted" style="font-size:80%">Branch Name</div>
                            <div class="h6"><?php echo $Branch['branch_name']?></div>
                         </div>
                        <div class="mt-1">
                            <div class="text-muted" style="font-style:80%">Branch Name</div>
                            <div class="h6"><?php echo $Branch['branch_name']?></div>
                         </div>
                        <div class="mt-1">
                            <div class="text-muted" style="font-style:80%">Phone Number</div>
                             <div class="h6"><?php echo $Branch['phone']?></div>
                         </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-style:80%">Email</div>
                            <div class="h6"><?php echo $Branch['email']?></div>
                         </div>
                         <div class="mt-1">
                            <div class="text-muted" style="font-style:80%">About Manager</div>
                            <div class="h6"><?php echo $Branch['about_manager']?></div>
                        </div>
                         <div class="mt-1">
                             <div class="text-muted" style="font-style:80%">Address</div>
                             <div class="h6"><?php echo $Branch['branch_address']?></div>
                         </div>
                       
                   </div>
               </div>
               <?php }?>
                 <div class="col-md-4">
                 <div class="card mt-5 p-3">
                   <div class="text-center h5" style="color:Violet">Membership Details</div>
                   <?php  foreach($MemberShips as $MemberShip){?>
                            <div class="mt-1">
                                <div class="text-muted" style="font-size:80%">Membership Name</div>
                                 <div class="h6"><?php echo $MemberShip['membership_name']?></div>
                            </div>
                            <div class="mt-1">
                                <div class="text-muted" style="font-size:80%">Validity</div>
                                 <div class="h6"><?php echo $MemberShip['validity']?></div>
                            </div>
                            <div class="mt-1">
                                <div class="text-muted" style="font-size:80%">Price</div>
                                 <div class="h6"><?php echo $MemberShip['price']?></div>
                            </div>
                             <div class="mt-1">
                                <div class="text-muted" style="font-size:80%">Description</div>
                                 <div class="h6"><?php echo $MemberShip['description']?></div>
                            </div>
                       </div>
                    </div>
                    <?php  } ?>
          <?php  }?>
                </div>
            </div>
