<?php include 'adminHead.php'; ?>
<?php include 'connection.php'; ?>
<?php 
$Branch_id = $_GET['Branch_id'];
$sql = "update Branches set  status = 'Activated' where Branch_id='".$Branch_id."' ";
if($conn->query($sql)==TRUE){
    $url =  "viewManager.php";
    header("Location:".$url);
}else{
    $url = "msg.php?msg=Something Went Wrong2&class=text-danger";
   header("Location:".$url);
}
?>