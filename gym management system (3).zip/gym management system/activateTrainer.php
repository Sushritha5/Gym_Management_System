<?php include 'managerHead.php'; ?>
<?php include 'connection.php'; ?>
<?php 
$GymTrainer_id = $_GET['GymTrainer_id'];
$sql = "update GymTrainer set  status = 'Activated' where GymTrainer_id='".$GymTrainer_id."' ";
if($conn->query($sql)==TRUE){
    $url =  "viewGymTrainer.php";
    header("Location:".$url);
}else{
    $url = "msg.php?msg=Something Went Wrong2&class=text-danger";
   header("Location:".$url);
}
?>