<?php include 'connection.php'; ?>
<?php include 'customerHead.php' ?>
<?php SESSION_start(); ?>
<?php 
    $MemberShip_id = $_POST['MemberShip_id'];
    $sql = "select * from Customer where MemberShip_id='".$MemberShip_id."' and Customer_id='".$_SESSION['Customer_id']."'";
    $reults = $conn->query($sql);
    if ($reults ->num_rows > 0) { 
        $url =  "msg.php?msg=Membership Already Enrolled &class=text-danger";;
        header("Location:".$url);
    }else{
        $sql = "update  Customer set MemberShip_id='".$MemberShip_id."' where  Customer_id='".$_SESSION['Customer_id']."' "; 
        if($conn->query($sql)==TRUE){
        $url =  "msg.php?msg=Membership Enrolled Successfully&class=text-success";;
        header("Location:".$url);
        }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
        }

    }
    
?>
