<?php SESSION_start(); ?>

<?php include 'connection.php'; ?>
<?php include 'managerHead.php'; ?>
<?php 
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $bmi = $_POST['bmi'];
    $bmr = $_POST['bmr'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $health_problems = $_POST['health_problems'];
    $address = $_POST['address'];
    $MemberShip_id = $_POST['MemberShip_id'];
    
    $sql = "insert into Customer(name,email,phone,password,bmi,bmr,height,weight,health_problems,address,MemberShip_id,Branch_id) 
    values('".$name."', '".$email."', '".$phone."', '".$password."', '".$bmi."', '".$bmr."','".$height."','".$weight."','".$health_problems."','".$address."','".$MemberShip_id."','".$_SESSION['Branch_id']."')"; 
    if($conn->query($sql)==TRUE){
        $url =  "msg.php?msg=Customer Added Successfully&class=text-success";;
        header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
    }
?>
?>