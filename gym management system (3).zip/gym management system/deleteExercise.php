<?php include 'connection.php'; ?>
<?php include 'gymHead.php' ?>
<?php 
    $ExcerciseDiet_id = $_GET['ExcerciseDiet_id'];
    $sql = "delete  from ExcerciseDiet where ExcerciseDiet_id='".$ExcerciseDiet_id."'"; 
    if($conn->query($sql)==TRUE){
        $url =  "viewManagerCustomer.php";
        header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
    }

?>
