<?php include 'head.php'?>
<?php include 'connection.php' ?>
<?php 
  $sql = "select * from Branches ";
  $results = $conn->query($sql);
?>
<div class="row m-auto">
    <div class="col-md-2" style="background-image:url('https://elements-cover-images-0.imgix.net/04d70c2c-f421-4ded-b705-e28a729c30be?auto=compress%2Cformat&fit=max&w=900&s=bed2e810f7e0885f242b7dd739fd3a21');height:100vh" ></div>
    <div class="col-md-10">
        <div class="card mt-4 p-2">
                <div class="text-center h4">Customer Registration</div>
                <form action="customerReg1.php" method="post">
                    <div class="row m-auto">
                        <div class="col-md-6 mt-3">
                            <label for="customer_name" class="form-label">Customer Name</label>
                            <input type="text" name="name" id="customer_name" placeholder="Enter Customer Name" required class="form-control">
                        </div>
                         <div class="col-md-6 mt-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="number" name="phone" id="phone" placeholder="Enter Phone Number" required class="form-control">
                        </div>
                        <div class="col-md-6 mt-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" id="email" placeholder="Enter Email" required class="form-control">
                        </div>
                         <div class="col-md-6 mt-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="password" id="password" placeholder="Enter Password" required class="form-control">
                          </div>
                          <div class="col-md-6 mt-3">
                            <label for="bmi" class="form-label">BMI</label>
                            <input type="text" name="bmi" id="bmi" placeholder="Enter BMI" required class="form-control">
                          </div>
                         <div class="col-md-6 mt-3">
                            <label for="bmr" class="form-label">BMR</label>
                            <input type="text" name="bmr" id="bmr" placeholder="Enter BMR" required class="form-control">
                        </div>
                        <div class="col-md-6 mt-3">
                            <label for="height" class="form-label">Height</label>
                            <input type="number" name="height" id="height" placeholder="Enter Height" required class="form-control">
                        </div>
                       <div class="col-md-6 mt-3">
                            <label for="weight" class="form-label">Weight</label>
                            <input type="number" name="weight" id="weight" placeholder="Enter Weight" required class="form-control">
                        </div>
                         <div class="col-md-6 mt-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea name="address" id="address" placeholder="Enter Address" required class="form-control"></textarea>
                          </div>
                         <div class="col-md-6 mt-3">
                            <label for="health_problems" class="form-label">Health Problems</label>
                             <textarea name="health_problems" id="health_problems" placeholder="Enter Problems" required class="form-control"></textarea>
                          </div>
                        <div class="col-md-6 mt-3">
                            <select name="Branch_id" required class="form-control">
                                 <option value="">Choose Branch</option>
                                   <?php foreach($results as $data){?>
                                    <option value="<?php echo $data['Branch_id']?>"><?php echo $data['branch_name']?></option>
                                    <?php }?>
                            </select>
                        </div>
                         <div class="col-md-6 mt-3">
                            <input type="submit" value="Register" class="btn btn-success w-100">
                         </div>
                     </div>
                </form>
            </div>
      </div>
</div>




