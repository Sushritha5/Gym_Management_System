<?php include 'connection.php'; ?>
<?php include 'adminHead.php'; ?>
<?php 
    $branch_name = $_POST['branch_name'];
    $manager_name = $_POST['manager_name'];
    $branch_address = $_POST['branch_address'];
    $about_manager = $_POST['about_manager'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    $sql = "insert into Branches(branch_name,branch_address,manager_name,about_manager,email,phone,password) 
    values('".$branch_name."', '".$branch_address."', '".$manager_name."', '".$about_manager."', '".$email."', '".$phone."','".$password."')"; 
    if($conn->query($sql)==TRUE){
        $url =  "msg.php?msg=Branch Manager Added Successfully&class=text-success";;
        header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
    }
?>
?>