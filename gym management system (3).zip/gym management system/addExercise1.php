<?php include 'connection.php'; ?>
<?php include 'gymHead.php' ?>
<?php 
    $Schedule_id = $_POST['Schedule_id'];
    $exercise_name = $_POST['exercise_name'];
    $description = $_POST['description'];

    $sql = "insert into ExcerciseDiet(exercise_name,description,Schedule_id)values('".$exercise_name."', '".$description."', '".$Schedule_id."')"; 
    if($conn->query($sql)==TRUE){
        $url =  "msg.php?msg=ExersiceDiet Added Successfully&class=text-success";;
        header("Location:".$url);
    }else{
        $url = "msg.php?msg=Something Went Wrong&class=text-danger";
        header("Location:".$url);
    }

   
    
?>
