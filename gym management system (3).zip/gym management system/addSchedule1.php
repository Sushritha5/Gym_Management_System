<?php include 'connection.php'; ?>
<?php include 'managerHead.php' ?>
<?php 
    $Customer_id = $_POST['Customer_id'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $MemberShip_id = $_POST['MemberShip_id'];
    $GymTrainer_id = $_POST['GymTrainer_id'];

    if ($GymTrainer_id ==''){
        $sql = "insert into Schedule(start_time,end_time,MemberShip_id,Customer_id)values('".$start_time."', '".$end_time."', '".$MemberShip_id."', '".$Customer_id."')"; 
        if($conn->query($sql)==TRUE){
            $url =  "msg.php?msg=Shedule  Added Successfully&class=text-success";;
            header("Location:".$url);
        }else{
            $url = "msg.php?msg=Something Went Wrong&class=text-danger";
            header("Location:".$url);
        }
       
    }else{
        $sql = "insert into Schedule(start_time,end_time,MemberShip_id,Customer_id,GymTrainer_id)values('".$start_time."', '".$end_time."', '".$MemberShip_id."', '".$Customer_id."','".$GymTrainer_id."')"; 
        if($conn->query($sql)==TRUE){
            $url =  "msg.php?msg=Shedule  Added Successfully&class=text-success";;
            header("Location:".$url);
        }else{
            $url = "msg.php?msg=Something Went Wrong&class=text-danger";
            header("Location:".$url);
        }
    }
   
    
?>
?>